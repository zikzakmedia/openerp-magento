<?php
class Openlabs_OpenERPConnector_OpenerpconnectorController extends Mage_Core_Controller_Front_Action
{

}
